interface User {
  userId: string;
  username: string;
  password: string;
  avatar: string;
  role?: string;
  tag?: string;
  createTime: number;
}
