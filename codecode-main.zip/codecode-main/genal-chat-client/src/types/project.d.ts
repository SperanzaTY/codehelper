interface Project {
    projectId: string;
    projectName: string;
    leader: string;
    groupId: string;
    groupName: string;
    ddl: any;
    detail: string;
    userId: string;
    tag: number;
}
