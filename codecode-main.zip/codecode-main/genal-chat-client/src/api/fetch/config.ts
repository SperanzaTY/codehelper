export const socketUrl = '/api';
