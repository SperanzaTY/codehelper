import fetch from '@/api/fetch';


/**
 * 获取项目主题
 * @param userId
 */
export async function getProjectMessage(userId: string) {
    return fetch.get(`/project/projectGroupId?userId=${userId}`);
}


export async function addProject() {
    return fetch.get(`/project/addProject`);
}


export async function updateProjectName(projectId: string, projectName: string) {
    return fetch.post(`/project/modifyProjectName?projectId=${projectId}&newProjectName=${projectName}`);
}

export async function updateProjectLeader(projectId: string, newLeader: string) {
    return fetch.post(`/project/modifyProjectLeader?projectId=${projectId}&newLeader=${newLeader}`);
}

export async function updateProjectDDL(projectId: string, newDdl: string) {
    return fetch.post(`/project/modifyProjectDdl?projectId=${projectId}&newDdl=${newDdl}`);
}

export async function updateProjectDetail(projectId: string, newDetail: string) {
    return fetch.post(`/project/modifyProjectDetail?projectId=${projectId}&newDetail=${newDetail}`);
}

export async function updateProjectUerId(projectId: string, newUserId: string) {
    return fetch.post(`/project/modifyProjectUserId?projectId=${projectId}&newUserId=${newUserId}`);
}

export async function updateProjectGroupId(projectId: string, newGroupId: string) {
    return fetch.post(`/project/modifyProjectGroupId?projectId=${projectId}&newGroupId=${newGroupId}`);
}

export async function updateProjectGroupName(projectId: string, newGroupName: string) {
    return fetch.post(`/project/modifyProjectGroupName?projectId=${projectId}&newGroupName=${newGroupName}`);
}

export function updateTag(projectId: string, newStatus: number) {
    return fetch.post(`/project/tag?projectId=${projectId}&newStatus=${newStatus}`);
}
