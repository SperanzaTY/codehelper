import fetch from '@/api/fetch';

/**
 * 群名模糊搜索用户
 * @param groupName
 */
export function getGroupsByName(groupName: string) {
  return fetch.get(`/group/findByName?groupName=${groupName}`);
}

export function getGroupsByName1(groupName: string) {
  return fetch.get(`/group/findByName1?groupName=${groupName}`).then(response => response.data)
      .then(data => {
        // 在这里处理返回的数据
        return data.data; // 返回你需要的值
      });
}


/**
 * 群分页消息
 * @param params
 */
export async function getGroupMessages(params: PagingParams) {
  return await fetch.get(`/group/groupMessages`, {
    params,
  });
}


/**
 * 根据用户id查询用户所在的所有群
 * @param userId
 */
export function getGroupsByUserId(userId: string) {
  return fetch.get(`/group/userId?userId=${userId}`);
}


/**
 * 根据账户id查询groupName
 * @param groupId
 */
export function getGroupById(groupId: string) {
    return fetch.get(`/group/findById?groupId=${groupId}`);
}
