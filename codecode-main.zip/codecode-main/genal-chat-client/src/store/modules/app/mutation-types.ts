export const SET_USER = 'set_user';
export const CLEAR_USER = 'clear_user';

export const SET_TOKEN = 'set_token';
export const SET_MOBILE = 'set_mobile';
export const SET_BACKGROUND = 'set_background';
