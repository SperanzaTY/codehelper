export interface AppState {
  user: User;
  project: Project;
  token: string;
  mobile: boolean;
  background: string;
}

const appState: AppState = {
  user: {
    userId: '',
    username: '',
    password: '',
    avatar: '',
    createTime: 0,
  },
  project: {
    projectId: '',
    projectName: '',
    leader: '',
    groupId: '',
    groupName: '',
    ddl: '',
    detail: '',
    userId: '',
    tag: 0,
  },
  token: '',
  mobile: false,
  background: '',
};

export default appState;
