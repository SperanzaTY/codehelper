<template>
  <div class="search">
    <div class="search-select">
      <a-select
        show-search
        placeholder="搜索聊天组"
        :default-active-first-option="false"
        :show-arrow="false"
        :filter-option="false"
        :not-found-content="null"
        @search="handleSearch"
      >
        <a-select-option v-for="(chat, index) in searchData" :key="index" @click="selectChat(chat)">
          <div v-if="chat.username">{{ chat.username }}</div>
          <div v-if="chat.groupName">{{ chat.groupName }}</div>
        </a-select-option>
      </a-select>

      <a-dropdown class="search-dropdown">
        <a-icon type="plus-circle" class="search-dropdown-button" />
        <a-menu slot="overlay">
          <a-menu-item>
            <div @click="() => (visibleAddGroup = !visibleAddGroup)">创建群</div>
          </a-menu-item>
          <a-menu-item>
            <div @click="() => (visibleJoinGroup = !visibleJoinGroup)">搜索群</div>
          </a-menu-item>
          <a-menu-item>
            <div @click="() => (visibleAddFriend = !visibleAddFriend)">搜索用户</div>
          </a-menu-item>
          <a-menu-item>
            <div @click="() => (visibleAddProject = !visibleAddProject)">创建项目</div>
          </a-menu-item>
        </a-menu>
      </a-dropdown>
    </div>

    <a-modal v-model="visibleAddGroup" footer="" title="创建群">
      <div style="display:flex">
        <a-input v-model="groupName" placeholder="请输入群名字"></a-input>
        <a-button @click="addGroup" type="primary">确定</a-button>
      </div>
    </a-modal>
    <a-modal v-model="visibleJoinGroup" footer="" title="搜索群">
      <div style="display:flex" v-if="visibleJoinGroup">
        <a-select
          show-search
          placeholder="请输入群名字"
          style="width: 90%"
          :default-active-first-option="false"
          :show-arrow="false"
          :filter-option="false"
          :not-found-content="null"
          @search="handleGroupSearch"
          @change="handleGroupChange"
        >
          <a-select-option v-for="(group, index) in groupArr" :key="index" @click="handleGroupSelect(group)">
            <div>{{ group.groupName }}</div>
          </a-select-option>
        </a-select>
        <a-button @click="joinGroup" type="primary">加入群</a-button>
      </div>
    </a-modal>
    <a-modal v-model="visibleAddFriend" footer="" title="搜索用户">
      <div style="display:flex" v-if="visibleAddFriend">
        <a-select
          show-search
          placeholder="请输入用户名"
          style="width: 90%"
          :default-active-first-option="false"
          :show-arrow="false"
          :filter-option="false"
          :not-found-content="null"
          @search="handleUserSearch"
          @change="handleUserChange"
        >
          <a-select-option v-for="(user, index) in userArr" :key="index" @click="handleUserSelect(user)">
            <div>{{ user.username }}</div>
          </a-select-option>
        </a-select>
        <a-button @click="addFriend" type="primary">添加好友</a-button>
      </div>
    </a-modal>
    <a-modal v-model="visibleAddProject" footer="" title="创建项目">
      <div class="input-container">
        <a-input v-model="project.projectName" addon-before="项目名称" placeholder="请输入项目名称"></a-input>
      </div>
      <div style="line-height: 2;">
        设置项目时间: <br>
        <a-range-picker @change="onChange" />
      </div>

      <div class="input-container">
        <div style="line-height: 2;">
          项目组: <br>
          <a-select
              show-search
              placeholder="请输入群名字"
              style="width:150px"
              :default-active-first-option="false"
              :show-arrow="false"
              :filter-option="false"
              :not-found-content="null"
              @search="handleGroupSearch"
              @change="handleGroupChange"
          >
            <a-select-option v-for="(group, index) in groupArr" :key="index" @click="handleGroupSelectName(group)">
              <div>{{ group.groupName }}</div>
            </a-select-option>
          </a-select>
        </div>
      </div>

      <div class="input-container">
          项目描述:
      </div>
      <div class="input-container">
        <a-textarea v-model="project.detail" placeholder="项目描述" :rows="4" />
      </div>

      <div class="complete-container">
        <a-button @click="addProject" type="primary">确认</a-button>
      </div>
    </a-modal>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator';
import { namespace } from 'vuex-class';
import { isContainStr, processReturn } from '@/utils/common.ts';
import * as apis from '@/api/apis';
import { nameVerify } from '@/utils/common';

const chatModule = namespace('chat');
const appModule = namespace('app');

@Component
export default class GenalSearch extends Vue {
  @appModule.Getter('user') user: User;
  @appModule.Getter('project') project: Project;
  @chatModule.State('activeRoom') activeRoom: Group & Friend;
  @chatModule.Getter('groupGather') groupGather: GroupGather;
  @chatModule.Getter('projectGather') projectGather: ProjectGather;
  @chatModule.Getter('friendGather') friendGather: FriendGather;

  visibleAddGroup: boolean = false;
  visibleJoinGroup: boolean = false;
  visibleAddFriend: boolean = false;
  visibleAddProject: boolean = false;
  groupName: string = '';
  searchData: Array<Group | Friend | Project> = [];
  groupId: string = '';
  groupArr: Array<Group> = [];
  friendId: string = '';
  userArr: Array<User> = [];
  projectArr: Array<Project> = [];


  created() {
    this.getSearchData();
  }

  @Watch('groupGather')
  changeGroupGather() {
    this.getSearchData();
  }

  @Watch('friendGather')
  changeFriendGather() {
    this.getSearchData();
  }

  @Watch('projectGather')
  changeProjectGather() {
    this.getSearchData();
  }

  getSearchData() {
    this.searchData = [...Object.values(this.groupGather), ...Object.values(this.friendGather), ...Object.values(this.projectArr)];
  }

  async addProject() {
    this.project.groupId = await apis.getGroupsByName1(this.groupName);
    let users = await apis.getUsersByGroupId(this.project.groupId);
    processReturn(users);
    this.visibleAddProject = false;
    for (const user of users.data['data']) {
      let data = await apis.addProject();
      this.project.userId = user;
      this.project.leader = this.user.username;
      await apis.updateProjectName(data.data['data'], this.project.projectName);
      await apis.updateProjectLeader(data.data['data'], this.project.leader);
      await apis.updateProjectDDL(data.data['data'], this.project.ddl);
      await apis.updateProjectDetail(data.data['data'], this.project.detail);
      await apis.updateProjectUerId(data.data['data'], this.project.userId);
      await apis.updateProjectGroupId(data.data['data'], this.project.groupId);
      await apis.updateProjectGroupName(data.data['data'], this.groupName);
    }
    this.project.projectName = '';
    this.project.groupName = '';
    this.project.detail = '';
  }

  handleSearch(value: string) {
    let mySearchData = [];
    this.searchData = [...Object.values(this.groupGather), ...Object.values(this.friendGather)];
    for (let chat of this.searchData) {
      // @ts-ignore
      if (chat.username) {
        // @ts-ignore
        if (isContainStr(value, chat.username)) {
          mySearchData.push(chat);
        }
        // @ts-ignore
      } else if (isContainStr(value, chat.groupName)) {
        mySearchData.push(chat);
      }
    }
    this.searchData = mySearchData;
  }

  async handleGroupSearch(value: string) {
    if (!value) {
      return;
    }
    let res = await apis.getGroupsByName(value);
    let data = processReturn(res);
    this.groupArr = data;
  }

  handleGroupSelect(group: Group) {
    this.groupId = group.groupId;
  }

  handleGroupSelectName(group: Group) {
    this.groupName = group.groupName;
  }

  handleGroupChange() {
    this.groupArr = [];
  }

  async handleUserSearch(value: string) {
    if (!value) {
      return;
    }
    let res = await apis.getUsersByName(value);
    let data = processReturn(res);
    this.userArr = data;
  }

  handleUserSelect(friend: Friend) {
    this.friendId = friend.userId;
  }

  handleUserChange() {
    this.userArr = [];
  }

  selectChat(activeRoom: User & Group) {
    this.$emit('setActiveRoom', activeRoom);
  }

  addGroup() {
    this.visibleAddGroup = false;
    if (!nameVerify(this.groupName)) {
      this.visibleAddGroup = true;
      return;
    }
    this.$emit('addGroup', this.groupName);
    this.groupName = '';
  }

  joinGroup() {
    this.visibleJoinGroup = false;
    this.$emit('joinGroup', this.groupId);
    this.groupId = '';
  }

  addFriend() {
    this.visibleAddFriend = false;
    this.$emit('addFriend', this.friendId);
    this.friendId = '';
  }

  onChange(date: Date | null, dateString: string) {
    this.project.ddl = dateString[1];
    console.log(date, dateString);
  }


}
</script>
<style lang="scss" scoped>

.input-label {
  display: inline-block;
  width: 120px;
}

.complete-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 10px;
}

.input-container {
  display: flex;
  margin-bottom: 10px; /* Adds bottom margin as spacing */
}

.search {
  position: relative;
  height: 60px;
  padding: 10px;
  display: flex;
  align-items: center;
  .search-select {
    width: 100%;
    .ant-select {
      width: 100%;
    }
  }
  .search-dropdown {
    position: absolute;
    right: 10px;
    top: 13px;
    width: 40px;
    height: 34px;
    font-size: 20px;
    cursor: pointer;
    line-height: 40px;
    color: gray;
    transition: 0.2s all linear;
    border-radius: 4px;
    &:hover {
      background-color: skyblue;
    }
  }
}
</style>
