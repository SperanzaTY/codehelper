export enum RCode {
  OK,
  FAIL,
  ERROR
}