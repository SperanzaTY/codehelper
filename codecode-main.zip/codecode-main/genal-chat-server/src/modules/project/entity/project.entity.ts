import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Project {
    @PrimaryGeneratedColumn("uuid")
    projectId: string;

    @Column({ default: 'Software Project' })
    projectName: string;

    @Column({ default: 'Project Leader' })
    leader: string;

    @Column({ default: 'Software Group ID' })
    groupId: string;

    @Column({ default: 'Software group' })
    groupName: string;

    @Column({ default: '' })
    ddl: string;

    @Column({ default: 'None' })
    detail: string;

    @Column({ default: '' })
    userId: string;

    @Column({ default: 0 })
    tag: number;

}
