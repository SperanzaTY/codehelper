import { Injectable } from '@nestjs/common';
import { Repository, Like } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from '../user/entity/user.entity';
import{ Project } from './entity/project.entity';
import { RCode } from 'src/common/constant/rcode';

@Injectable()
export class ProjectService {
    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
        @InjectRepository(Project)
        private readonly projectRepository: Repository<Project>
    ) {}

    // async
    async addProject(project: Project = new Project()){
        console.log(project);
        try {
            // 执行添加项目的逻辑，例如将项目数据保存到数据库
            const data = await this.projectRepository.insert(project);

            // 返回成功消息和添加的项目数据
            return {
                msg: '项目添加成功',
                data: project.projectId,
            };
        } catch (e) {
            // 处理添加项目时的错误
            return {
                code: RCode.ERROR,
                msg: '项目添加失败',
                data: e,
            };
        }
    }
    async postProject(projectId: string){
        try{
            if(projectId){
                const projectIdArr = projectId.split(',');
                const projectArr = [];
                for(const projectId of projectIdArr) {
                    const data = await this.projectRepository.findOne({projectId: projectId});
                    projectArr.push(data);
                }
                return { msg:'获取項目信息成功', data: projectArr};
            }
            return {code: RCode.FAIL, msg:'获取項目信息失败', data: null};
        }
        catch (e) {
            return {code: RCode.ERROR, msg: '获取項目信息失败', data: e};
        }
    }

  async getProjectByName(projectName: string) {
    try {
      if(projectName) {
        const data = await this.projectRepository.find({projectName: Like(`%${projectName}%`)});
        return {data: data};
      }
      return {code: RCode.FAIL, msg:'请输入項目名稱', data: null};
    } catch(e) {
      return {code: RCode.ERROR, msg:'查找項目錯誤', data: null};
    }
  }

    async getLeader(leader: string) {
    try {
        let data;
        if(leader) {
            data = await this.projectRepository.find({leader: leader});
            return { msg:'获取項目負責人成功', data};
        }
    }
    catch (e) {
      return {code: RCode.ERROR, msg:'获取項目負責人失败',data: e};
    }
  }

    async getProjectByGroup(userId: string) {
    try {
        if(userId) {
            const data = await this.projectRepository.find({
                where: {userId: userId}
            });
            return {data};
        }
        return {code: RCode.FAIL, msg:'請輸入群組id', data: null};
    }
    catch(e) {
        return {code: RCode.ERROR, msg:'根據群組id查找項目錯誤', data: null};
    }
  }

      async getDdl(projectId: string) {
        try {
            let data;
            if(projectId) {
                data = await this.userRepository.findOne({
                    where:{projectId: projectId}
                });
                return { msg:'获取项目ddl成功', data: data};
            }
        } catch(e) {
            return { code: RCode.ERROR , msg:'获取项目ddl失败', data: e };
        }
    }

    async getDetail(projectId: string) {
        try {
            let data;
            if(projectId) {
                data = await this.userRepository.findOne({
                    where:{projectId: projectId}
                });
                return { msg:'获取项目详情成功', data };
            }
        } catch(e) {
            return { code: RCode.ERROR , msg:'获取项目详情失败', data: e };
        }
    }

    async deleteProject(projectId: string) {
        try {
            if (projectId) {
                const project = await this.projectRepository.findOne({ projectId });
                if (project) {
                    await this.projectRepository.delete(projectId);
                    return { msg: '刪除項目成功', data: project };
                }
                else {
                    return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
                }
            }
            else {
                return { code: RCode.FAIL, msg: '缺少項目ID', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '刪除項目失敗', data: e };
        }
    }

    async modifyProjectName(projectId: string, newProjectName: string) {
        console.log(projectId, newProjectName)
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.projectName = newProjectName;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目名稱成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目名稱失敗', data: e };
        }
    }

    async modifyProjectLeader(projectId: string, newLeader: any) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.leader = newLeader;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目負責人成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目負責人失敗', data: e };
        }
    }

    async modifyProjectDdl(projectId: string, newDdl: string) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.ddl = newDdl;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目交付時間成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目交付時間失敗', data: e };
        }
    }

    async modifyProjectDetail(projectId: string, newDetail: string) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.detail = newDetail;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目详情成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目详情失敗', data: e };
        }
    }

    async modifyProjectUserId(projectId: string, newUserId: string) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.userId = newUserId;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目详情成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目详情失敗', data: e };
        }
    }

    async modifyProjectGroupId(projectId: string, newGroupId: string) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.groupId = newGroupId;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目详情成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目详情失敗', data: e };
        }
    }

    async modifyProjectGroupName(projectId: string, newGroupName: string) {
        try {
            const existingProject = await this.projectRepository.findOne({ projectId });

            if (existingProject) {
                existingProject.groupName = newGroupName;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改項目详情成功', data: modifiedProject };
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的項目', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改項目详情失敗', data: e };
        }
    }

    async modifyTag(projectId: string, newStatus: number) {
        try {
            // @ts-ignore
            const existingProject = await this.projectRepository.findOne(
                {where: {projectId: projectId}}
            );
            if (existingProject) {
                existingProject.tag = newStatus;
                const modifiedProject = await this.projectRepository.save(existingProject);
                return { msg: '修改工作完成情況成功', data: modifiedProject.tag};
            }
            else {
                return { code: RCode.FAIL, msg: '找不到指定的個人工作完成情況', data: null };
            }
        }
        catch (e) {
            return { code: RCode.ERROR, msg: '修改工作完成情況详情失敗', data: e };
        }
    }
}
