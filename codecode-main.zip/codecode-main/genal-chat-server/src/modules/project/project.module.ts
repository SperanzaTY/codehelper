import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../user/entity/user.entity';
import { Project } from './entity/project.entity';
import { ProjectController } from './project.controller';
import { ProjectService } from './project.service';
import { Group, GroupMap } from '../group/entity/group.entity';
import { GroupMessage } from '../group/entity/groupMessage.entity';
import { UserMap } from '../friend/entity/friend.entity';
import { FriendMessage } from '../friend/entity/friendMessage.entity';

@Module({
    imports: [
        TypeOrmModule.forFeature([Project, User, Group, GroupMap, GroupMessage, UserMap, FriendMessage])
    ],
    providers: [ProjectService],
    controllers: [ProjectController],
})
export class ProjectModule {}
