import { Controller, Post, Get,
    Body, Query, Patch, Param, Delete, UseInterceptors,
    UploadedFile, UseGuards } from '@nestjs/common';
import { UserService } from '../user/user.service';
import {ProjectService } from './project.service';
import { FileInterceptor } from '@nestjs/platform-express';
import { AuthGuard } from '@nestjs/passport';
import {query} from "express";
import {Project} from "./entity/project.entity";

@Controller('project')
@UseGuards(AuthGuard('jwt'))
export class ProjectController {
    constructor(private readonly projectService: ProjectService) {}

    @Get('/addProject')
    addProject(@Body('project') project: Project) {
        return this.projectService.addProject(project);
    }

    @Get('/projectId')
    getProject(@Query('projectId') projectId: string) {
        return this.projectService.postProject(projectId);
    }

    @Get('/projectName')
    getProjectByName(@Query('projectName')projectName: string){
        return this.projectService.getProjectByName(projectName);
    }

    @Get('/projectLeader')
    getLeader(@Query('leader') leader: string) {
        return this.projectService.getLeader(leader);
    }

    @Get('/projectGroupId')
    getProjectByGroup(@Query('userId')userId: string){
        return this.projectService.getProjectByGroup(userId);
    }

    @Get('/projectDdl')
    getDdl(@Query('ddl') ddl: string) {
        return this.projectService.getDdl(ddl);
    }

    @Get('/projectDetail')
    getDetail(@Query('detail') detail: string) {
        return this.projectService.getDetail(detail);
    }

    @Delete('/deleteProject')
    deleteProject(@Query('projectId') projectId: string) {
        return this.projectService.deleteProject(projectId);
    }

    @Post('/modifyProjectName')
        async modifyProjectName(
            @Query('projectId') projectId: string,
            @Query('newProjectName') newProjectName: string,
        ) {
        return this.projectService.modifyProjectName(projectId, newProjectName);
    }

    @Post('/modifyProjectLeader')
        async modifyProjectLeader(
            @Query('projectId') projectId: string,
            @Query('newLeader') newLeader: string,
        ) {
        return this.projectService.modifyProjectLeader(projectId, newLeader);
    }

    @Post('/modifyProjectDdl')
        async modifyProjectDdl(
            @Query('projectId') projectId: string,
            @Query('newDdl') newDdl: string,
        ) {
        return this.projectService.modifyProjectDdl(projectId, newDdl);
    }

    @Post('/modifyProjectDetail')
        async modifyProjectDetail(
            @Query('projectId') projectId: string,
            @Query('newDetail') newDetail: string,
        ) {
        return this.projectService.modifyProjectDetail(projectId, newDetail);
    }

    @Post('/modifyProjectUserId')
    async modifyProjectUserId(
        @Query('projectId') projectId: string,
        @Query('newUserId') newUserId: string,
    ) {
        return this.projectService.modifyProjectUserId(projectId, newUserId);
    }

    @Post('/modifyProjectGroupId')
    async modifyProjectGroupId(
        @Query('projectId') projectId: string,
        @Query('newGroupId') newGroupId: string,
    ) {
        return this.projectService.modifyProjectGroupId(projectId, newGroupId);
    }

    @Post('/modifyProjectGroupName')
    async modifyProjectGroupName(
        @Query('projectId') projectId: string,
        @Query('newGroupName') newGroupName: string,
    ) {
        return this.projectService.modifyProjectGroupName(projectId, newGroupName);
    }

    @Post('/tag')
    async modifyTag(
        @Query('projectId') projectId: string,
        @Query('newStatus') newStatus: number,
    ) {
        return this.projectService.modifyTag(projectId, newStatus);
    }

}
