export const jwtConstants = {
  secret: 'genal-chat',
};
