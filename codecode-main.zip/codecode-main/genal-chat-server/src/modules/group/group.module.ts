/*
*   @nestjs/common 中包含了 Nest.js 框架中常用的模組和裝飾器。
*   @nestjs/typeorm 是 Nest.js 中與 TypeORM 整合的模組，用於方便地在 Nest.js 應用中使用 TypeORM。
*/
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

/*
*   處理業務邏輯和處理 HTTP 請求的類別
*/
import { GroupService } from './group.service';
import { GroupController } from './group.controller';

/*
*   引入了與 TypeORM 相關的實體類別（Entity）。
*   在這裡，Group、GroupMap 和 GroupMessage 是與數據庫表相對應的實體類別。
*/
import { Group, GroupMap } from './entity/group.entity';
import { GroupMessage } from './entity/groupMessage.entity';

@Module({
  //  使用 TypeOrmModule.forFeature 將 Group、GroupMap 和 GroupMessage 注冊到 TypeORM 中，
  //  以便在模塊中使用這些實體類別進行數據操作。
  imports: [
    TypeOrmModule.forFeature([Group, GroupMap, GroupMessage]),
  ],

  //  列舉了提供給模塊使用的提供者，
  //  這裡只有 GroupService，它通常包含與業務邏輯相關的方法。
  providers: [GroupService],

  //  列舉了模塊中的控制器，
  //  這裡只有 GroupController，它處理 HTTP 請求並調用相應的服務方法。
  controllers: [GroupController],
})
export class GroupModule {}
