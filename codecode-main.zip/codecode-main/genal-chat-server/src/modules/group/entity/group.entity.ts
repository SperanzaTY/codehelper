//  導入TypeORM：一個針對 TypeScript 和 JavaScript 的對象關係映射（ORM）庫
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

//  定義一個名為 Group 的實體（Entity）
@Entity()
export class Group {
  //  使用 PrimaryGeneratedColumn 裝飾器
  /*
  *   指定 groupId 為主鍵
  *   使用 UUID 作為生成策略
  */
  @PrimaryGeneratedColumn("uuid")
  groupId: string;

  //  使用 Column 裝飾器
  @Column()
  userId: string;

  //  使用 Column 裝飾器
  @Column()
  groupName: string;

  //  使用 Column 裝飾器
  //  公告
  @Column({ default: '群主很懒,没写公告' })
  notice: string;

  //  使用 Column 裝飾器
  /*
  *   設定類型為 'double'，
  *   默認值為當前日期的時間戳
  */
  @Column({type: 'double',default: new Date().valueOf()})
  createTime: number;
}

//  定義一個名為 GroupMap 的實體（Entity）
@Entity()
export class GroupMap {
  //  使用 PrimaryGeneratedColumn 裝飾器
  /*
  *   指定 _id 為主鍵
  */
  @PrimaryGeneratedColumn()
  _id: number;

  //  使用 Column 裝飾器
  @Column()
  groupId: string;

  //  使用 Column 裝飾器
  @Column()
  userId: string;
}

