//  導入TypeORM：一個針對 TypeScript 和 JavaScript 的對象關係映射（ORM）庫
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

//  定義一個名為 GroupMessage 的實體（Entity）
@Entity()
export class GroupMessage {
  //  使用 PrimaryGeneratedColumn 裝飾器
  /*
  *   指定 _id 為主鍵
  */
  @PrimaryGeneratedColumn()
  _id: number;

  //  使用 Column 裝飾器
  @Column()
  userId: string;

  //  使用 Column 裝飾器
  @Column()
  groupId: string;

  //  使用 Column 裝飾器
  @Column()
  content: string;

  //  使用 Column 裝飾器
  @Column()
  messageType: string;

  //  使用 Column 裝飾器
  /*
  *   設定類型為 'double'
  */
  @Column('double')
  time: number;
}
