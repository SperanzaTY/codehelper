import { Injectable } from '@nestjs/common';
import { Repository, Like, getRepository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Group, GroupMap } from './entity/group.entity';
import { GroupMessage } from './entity/groupMessage.entity';
import { RCode } from 'src/common/constant/rcode';
import { User } from '../user/entity/user.entity';

/*
* GroupService類別主要用於處理關於群組和群組消息的相關操作。
*   這些操作包括根據群組ID獲取群組信息、根據用戶ID獲取其所有群組、根據群組ID獲取所有用戶信息以及獲取群組消息等。
*   該類別使用了 @nestjs/typeorm 提供的注入存儲庫的方式，並使用了 TypeScript 中的異步操作。
*/

@Injectable()
export class GroupService {
  constructor(
      //  這個語句注入了一個 Group 實體對應的 typeorm 存儲庫實例(Repository)，
      //  該實例被賦值給 groupRepository 屬性。
      //  這個 Repository 將被用於執行與 Group 實體相關的數據存取操作。
    @InjectRepository(Group)
    private readonly groupRepository: Repository<Group>,

      //  這個語句注入了一個 GroupMap 實體對應的 typeorm 存儲庫實例(Repository)，
      //  該實例被賦值給 groupUserRepository 屬性。
      //  這個 Repository 將被用於執行與 GroupMap 實體相關的數據存取操作。
    @InjectRepository(GroupMap)
    private readonly groupUserRepository: Repository<GroupMap>,

      //  這個語句注入了一個 GroupMessage 實體對應的 typeorm 存儲庫實例(Repository)，
      //  該實例被賦值給 groupMessageRepository 屬性。
      //  這個 Repository 將被用於執行與 GroupMessage 實體相關的數據存取操作。
    @InjectRepository(GroupMessage)
    private readonly groupMessageRepository: Repository<GroupMessage>,
  ) {}

  // 定義了一個異步方法，用於獲取指定群組ID的群組信息
  async postGroups(groupIds: string) {
    try {
      if(groupIds) {
        const groupIdArr = groupIds.split(',');
        const groupArr = [];
        for(const groupId of groupIdArr) {
          const data = await this.groupRepository.findOne({groupId: groupId});
          groupArr.push(data);
        }
        return { msg:'获取群信息成功', data: groupArr};
      }
      return {code: RCode.FAIL, msg:'获取群信息失败', data: null};
    } catch (e) {
      return {code: RCode.ERROR, msg:'获取群失败',data: e};
    }
  }

  // 定義了一個異步方法，用於獲取指定用戶ID的所有群組信息
  async getUserGroups(userId: string) {
    try {
      let data;
      if(userId) {
        data = await this.groupUserRepository.find({userId: userId});
        return { msg:'获取用户所有群成功', data};
      }
      data = await this.groupUserRepository.find();
      return { msg:'获取系统所有群成功', data};
    } catch (e) {
      return {code: RCode.ERROR, msg:'获取用户的群失败',data: e};
    }
  }

  // 定義了一個異步方法，用於獲取指定群組ID的所有用戶信息
  async getGroupUsers(groupId: string) {
    try {
      let data;
      if(groupId) {
        data = await this.groupUserRepository.find({groupId: groupId});
        return { msg:'获取群的所有用户成功', data};
      }
    } catch (e) {
      return {code: RCode.ERROR, msg:'获取群的用户失败',data: e};
    }
  }

  // 定義了一個異步方法，用於獲取指定群組ID的消息
  async getGroupMessages(groupId: string, current: number, pageSize: number) {
    let groupMessage = await getRepository(GroupMessage)
    .createQueryBuilder("groupMessage")
    .orderBy("groupMessage.time", "DESC")
    .where("groupMessage.groupId = :id", { id: groupId })
    .skip(current)
    .take(pageSize)
    .getMany();
    groupMessage = groupMessage.reverse();

    const userGather: {[key: string]: User} = {};
    let userArr: FriendDto[] = [];
    for(const message of groupMessage) {
      if(!userGather[message.userId]) {
        userGather[message.userId] = await getRepository(User)
        .createQueryBuilder("user")
        .where("user.userId = :id", { id: message.userId })
        .getOne();
      }
    }
    userArr = Object.values(userGather);
    return {msg: '', data: { messageArr: groupMessage, userArr: userArr }};
  }

  //  定義了一個異步方法，用於根據群組名稱獲取群組信息
  async getGroupsByName(groupName: string) {
    try {
      if(groupName) {
        const groups = await this.groupRepository.find({groupName: Like(`%${groupName}%`)});
        return { data: groups};
      }
      return {code: RCode.FAIL, msg:'请输入群昵称', data: null};
    } catch(e) {
      return {code: RCode.ERROR, msg:'查找群错误', data: null};
    }
  }

  async getGroupsByName1(groupName: string) {
    try {
      if(groupName) {
        const group = await this.groupRepository.findOne({groupName: groupName});
        return { data: group.groupId};
      }
      return {code: RCode.FAIL, msg:'请输入群昵称', data: null};
    } catch(e) {
      return {code: RCode.ERROR, msg:'查找群错误', data: null};
    }
  }

  async getGroupsById(groupId: string) {
    try {
      if(groupId) {
        const group = await this.groupRepository.findOne({groupId: groupId});
        return { data: group.groupName};
      }
      return {code: RCode.FAIL, msg:'请输入群昵称', data: null};
    } catch(e) {
      return {code: RCode.ERROR, msg:'查找群错误', data: null};
    }
  }

// 定義了一個異步方法，用於獲取指定群組ID的 Todolist
async getGroupTodolist(groupId: string) {
  try {
    if (groupId) {
      // Assuming there is a Todolist entity and repository in your application
      // Replace TodolistEntity and TodolistRepository with your actual entity and repository names
      const todolistItems = await this.groupRepository.find({ groupId: groupId });
      return { msg: '获取群 Todolist 成功', data: todolistItems };
    }
    return { code: RCode.FAIL, msg: '缺少群組ID', data: null };
  } catch (e) {
    return { code: RCode.ERROR, msg: '获取群 Todolist 失败', data: null };
  }
}

    async getGroupNameByUserId(userId: string) {
        try {
            if(userId) {
                const data = await this.groupRepository.find({userId: userId});
                return {data: data};
            }
            return {code: RCode.FAIL, msg:'请输入用戶名稱', data: null};
        }
        catch(e) {
            return {code: RCode.ERROR, msg:'查找群名失敗', data: null};
            }
    }

}
