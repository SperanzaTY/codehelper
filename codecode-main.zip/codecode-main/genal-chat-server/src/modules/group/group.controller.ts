//  導入
//  這些裝飾器用於定義控制器類、HTTP 請求方法以及相關的參數和中間件
import { Controller, Post, Get, Body, Query, UseGuards } from '@nestjs/common';
//  導入了 GroupService 類，用於處理與群組相關的業務邏輯。
//  這是一個服務類，負責處理控制器中定義的不同請求方法的實際邏輯。
import { GroupService } from './group.service';
//  導入了 NestJS 的 Passport 模組中的 AuthGuard，該模組用於處理身份驗證相關的邏輯。
import { AuthGuard } from '@nestjs/passport';

/*
* @Controller： 一個 NestJS 的 Controller 裝飾器，將這個類定義為一個控制器，
*      prefix： 處理路徑為 '/group' 的請求。
*
* @UseGuards： 使用中間件的裝飾器，指定了 AuthGuard 中間件，它用於確保只有通過身份驗證的用戶才能訪問這個控制器的路由。
*      策略：JWT
*/
@Controller('group')
@UseGuards(AuthGuard('jwt'))
export class GroupController {
  //  這是控制器的構造函數，
  //  接受一個 GroupService 實例作為參數，並將其保存在私有變量 groupService 中，以便在控制器的其他方法中使用。
  constructor(private readonly groupService: GroupService) {}

  /*
  * @Post：  定義的 HTTP POST 請求方法，處理 '/group' 路徑的請求。
  * @Body：  提取 POST 請求的主體中的 groupIds 參數，這個參數的類型被指定為 string。
  */
  @Post()
  postGroups(@Body('groupIds') groupIds: string) {
    return this.groupService.postGroups(groupIds);
  }

  /*
  *   getUserGroups 方法處理 '/group/userGroup' 路徑，接受 userId 參數。
  */
  @Get('/userGroup')
  getUserGroups(@Query('userId') userId: string) {
    return this.groupService.getUserGroups(userId);
  }

  /*
  *   getGroupUsers 方法處理 '/group/groupUser' 路徑，接受 groupId 參數。
  */
  @Get('/groupUser')
  getGroupUsers(@Query('groupId') groupId: string) {
    return this.groupService.getGroupUsers(groupId);
  }

  /*
  *   getGroupByName 方法處理 '/group/findByName' 路徑，接受 groupName 參數。
  */
  @Get('/findByName')
  getGroupsByName(@Query('groupName') groupName: string) {
    return this.groupService.getGroupsByName(groupName);
  }

  @Get('/findByName1')
  getGroupsByName1(@Query('groupName') groupName: string) {
    return this.groupService.getGroupsByName1(groupName);
  }

  @Get('/findById')
  getGroupsById(@Query('groupId') groupId: string) {
    return this.groupService.getGroupsById(groupId);
  }

  /*
  *   getMessages 方法處理 '/group/groupMessages' 路徑，接受 groupId 參數。
  */
  @Get('/groupMessages')
  getGroupMessages(@Query('groupId') groupId: string, @Query('current') current: number, @Query('pageSize') pageSize: number) {
    return this.groupService.getGroupMessages(groupId, current, pageSize);
  }

  /*
  *   getTodolist 方法處理 '/group/groupTodolist' 路徑，接受 groupId 參數。
  */
  @Get('/groupTodolist')
  getGroupTodolist(@Query('groupId') groupId: string) {
    return this.groupService.getGroupTodolist(groupId);
  }

    @Get('/userId')
    getGroupNameByUserId(@Query('userId') userId: string) {
        return this.groupService.getGroupNameByUserId(userId);
    }


}
